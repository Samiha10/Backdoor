<!DOCTYPE html>
<html>
<head>
	<title>Backdoor</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="assets/css/contact.css">
	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<script src="assets/js/jquery.min.js"></script>
  <script src="assets/js/bootstrap.min.js"></script>
</head>
<body style="background-color: #A9A9A9;">

<div class="navsection custom_nv_bg_col" id="navstart">
				<div class="container">
					<nav class="navbar navbar-expand-lg navbar-light">
						<a class="navbar-brand" href="#">
							<img src="assets/image/logo-01.png" alt="!">
						</a>
						<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
						<span class="navbar-toggler-icon"></span>
						</button>
						
						<div class="collapse navbar-collapse" id="navbarSupportedContent">
							<ul class="navbar-nav ml-auto">
								<li class="nav-item">
									<a class="nav-link" href="homepage.html">Home <span class="sr-only"></span></a>
								</li>
								
								<li class="nav-item">
									<a class="nav-link" href="about.html">About Us</a>
								</li>
								<li class="nav-item">
									<a class="nav-link" href="services.html">Services</a>
								</li>
								<li class="nav-item active">
									<a class="nav-link" href="#">Contact</a>
								</li>
								<li class="nav-item">
									<a class="nav-link" href="team.html">Our Team</a>
								</li>
								
							</ul>
						</div>
					</nav>
				</div>
			</div>


		<div class="containerr">
<h2 style="font-family: arial;">CONTACT US</h2>
<p style="font-family: arial;font-size: 18px;">Secure your System by monitoring 24/7</p>
		</div>

<div class="container" style="background:#A9A9A9;width: 100%;
	height: auto;font-family: arial;
	color:black;">
	 <div class="row">
	<div class="col-sm-5" style="font-size: 20px;line-height: 1.6;text-align: center;">
<p><i class="fa fa-map-marker" aria-hidden="true" style="padding-right:10px;color: white;padding-top:180px;"></i>
House :197/A Road #1,<br>Mohakhali
 DOHS <br>Dhaka-1215,Bangladesh</p>
<p><i class="fa fa-phone" aria-hidden="true" style="padding-right:10px;color: white;"></i><span>
+8801755555560</span></p>
<p><i class="fa fa-calendar" aria-hidden="true" style="padding-right:10px;color: white;"></i><span>
Sat-Thu(9am-6 pm)</span></p>
<p><i class="fa fa-envelope" aria-hidden="true" style="padding-right:10px;color: white;"></i><span>
info@backdoor.com.bd</span></p>
	</div>
	<div class="col-sm-7" style="padding-top:80px;text-align: center;">
		<form method="post">
		<input type="text" name="name" placeholder="Enter your name" required="" style="width:55%;height: 50px;padding-left:5px;border:1px solid transparent; border-radius:10px;"><br><br>
		<input type="text" name="email" placeholder="Enter your email" required="" style="width:55%;height: 50px;padding-left:5px;border:1px solid transparent; border-radius:10px;"><br><br>
		<input type="text" name="phone" placeholder="Enter your phone no." required="" style="width:55%;height: 50px;padding-left:5px;border:1px solid transparent; border-radius:10px;"><br><br>
		<input type="text" name="subject" placeholder="Subject" required="" style="width:55%;height: 50px;padding-left:5px;border:1px solid transparent; border-radius:10px;"><br><br>



		<div class="message" style="text-align: center;"><input type="text" name="message" placeholder="Message Here" style="width:55%;height: 50px;padding-top:20px;padding-bottom:120px;margin-bottom: 30px;padding-left:5px;border:1px solid transparent; border-radius:10px;" required=""><br>
<?php
$dsn="mysql:host=localhost;dbname=backdoor";
$user="root";
$pass="";
$con=new PDO($dsn,$user,$pass);
if($con){
if (isset($_POST['submit'])) {

	$name=$_POST['name'];
	$email=$_POST['email'];
	$phone=$_POST['phone'];
	$subject=$_POST['subject'];
	$message=$_POST['message'];
	
	$sql = 'INSERT INTO contact(name,email,phone,subject,message) VALUES (?,?,?,?,?)';
	$stmt = $con->prepare($sql);
	$stmt->bindParam(1, $name);
    $stmt->bindParam(2, $email);
    $stmt->bindParam(3, $phone);
    $stmt->bindParam(4, $subject);
    $stmt->bindParam(5, $message);

if($stmt->execute()){
echo '<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>';
		
echo '<script language="javascript">';
echo 'sweetAlert( "Thank You!", "Message sent successfully","success")';
echo '</script>';
$con= null;
}
else{
	echo '<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>';
echo '<script language="javascript">';
echo 'sweetAlert("Oops!","Failed","error")';
echo '</script>';
  }
}
}
$con= null;
?>


		</div>
	 <input type="submit" value="Send"  name="submit" style="margin-bottom: 100px;border: 1px solid white;background: white;border-radius:10px;color:black;padding:5px 35px;">
	</form>
	</div>
</div>
</div>

<div class="footer" style="background-color:#000000;width: 100%;height:230px;text-align: center">
	<p style="padding-top:45px;color:white">Copyright ©2020 All rights reserved |</p>
	<p style="color: white;padding-bottom:5px;"> This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by Backdoor Private Limited</p>
	<div class="icon" style="display:inline-flex;text-align: center;">
		<a href="https://www.facebook.com/backdoor.com.bd/" style="border:1px solid black;border-radius:50%;padding: 10px 17px;margin-right:10px;color:black;background-color:white;"><i class="fa fa-facebook" aria-hidden="true"></i></a>
		<a href="" style="border:1px solid black;border-radius:50%;padding: 10px 13px;margin-right:10px;color:black;background-color:white;"><i class="fa fa-twitter" aria-hidden="true"></i></a>
		<a href="" style="border:1px solid black;border-radius:50%;padding: 10px 15px;color:black;background-color:white;"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
	</div>

</div>
</body>
</html>